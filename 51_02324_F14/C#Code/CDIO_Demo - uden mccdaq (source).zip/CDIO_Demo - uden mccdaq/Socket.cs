﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CDIO_Demo
{
    using System;
    using System.Net;
    using System.Net.Sockets;
    using System.Text;

    public class SocketListener
    {

        // Create a TCP/IP socket.
        Socket listener;



        // Incoming data from the client.
        public string data = null;

        public SocketListener()
        { 
            listener = new Socket(AddressFamily.InterNetwork,
            SocketType.Stream, ProtocolType.Tcp);
            StartListening();
        }


        public void StartListening()
        {
            // Data buffer for incoming data.
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.
            // Dns.GetHostName returns the name of the 
            // host running the application.
            IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);



            

            JavaConverter javaConverter;


            // Bind the socket to the local endpoint and 
            // listen for incoming connections.
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.
                while (true)
                {
                    Console.WriteLine("Waiting for a connection..." + localEndPoint.Address.ToString() + ":" + localEndPoint.Port.ToString());
                    // Program is suspended while waiting for an incoming connection.
                    Socket handler = listener.Accept();
                    data = null;

                    byte[] msg;

                    //msg = Encoding.ASCII.GetBytes("CONNECTED");

                    //handler.Send(msg);




                    // An incoming connection needs to be processed.
                    while (true)
                    {
                        bytes = new byte[1024];
                        int bytesRec = handler.Receive(bytes);
                        data += Encoding.ASCII.GetString(bytes, 0, bytesRec);

                        //javaConverter = new JavaConverter(data);

                        

                        if (data.IndexOf("<EOF>") > -1)
                        {
                            break;
                        }
                    }

                    // Show the data on the console.
                    Console.WriteLine("Text received : {0}", data);

                    // Echo the data back to the client.
                    msg = Encoding.ASCII.GetBytes(data);

                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }

        //public Boolean connectUSB()
        //{
        //    usbConnection = new UsbConnection(0, 0, 0);

        //    if (!usbConnection.connect())
        //    {
        //        //msg = Encoding.ASCII.GetBytes("ERROR;42;NO USB DEVICE CONNECTED");

        //        //handler.Send(msg);

        //        //handler.Shutdown(SocketShutdown.Both);
        //        //handler.Close();
        //        return false;
        //        Console.WriteLine("NO USB DEVICE CONNECTED");

        //    }

        //    return true;
        //}






    }
}
