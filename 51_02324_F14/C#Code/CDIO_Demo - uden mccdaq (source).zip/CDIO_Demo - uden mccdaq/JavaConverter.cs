﻿using System;
using System.Collections.Generic;

using System.Text;

namespace CDIO_Demo
{
    class JavaConverter
    {
        private int port;

        public int Port
        {
            get { return port; }
            set { port = value; }
        }
        private int numberOfReadings;

        public int NumberOfReadings
        {
            get { return numberOfReadings; }
            set { numberOfReadings = value; }
        }
        private int readingPeriod;

        public int ReadingPeriod
        {
            get { return readingPeriod; }
            set { readingPeriod = value; }
        }
        private string javaString;
        private int[] javaInputInts = new int[3];
        private string toJavaString;
        private string data;



        public JavaConverter(String data)
        {
            javaOutputConverter(data);
        }

        //  Converts the input, we get from java to ints and saved them with apropriate names.
        public void javaOutputConverter(String javaString)
        {
            String[] javaStringSplit = javaString.Split(';');
            this.port               = Convert.ToInt32(javaStringSplit[0]);
            this.numberOfReadings   = Convert.ToInt32(javaStringSplit[1]);
            this.readingPeriod      = Convert.ToInt32(javaStringSplit[2]);
        }

        //  Converts the output, that we send to java, to a formatted String.
        public void javaInputConverter(String data, int port, int timeStamp)
        {
            this.toJavaString = data + ";" + port + ";" + timeStamp + ";";
        }

    }
}
