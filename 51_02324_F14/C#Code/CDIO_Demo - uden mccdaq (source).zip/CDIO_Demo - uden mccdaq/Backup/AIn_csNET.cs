// ==============================================================================

//  File:							AIn_csNET.CS

//  Library Call Demonstrated:		Mccdaq.MccBoard.AIn()

//  Purpose:						Reads an A/D Input Channel.

//  Demonstration:					Displays the analog input on channel 0.

//  Other Library Calls:			Mccdaq.MccBoard.ToEngUnits()
//									MccDaq.MccService.ErrHandling()

//  Special Requirements:			Board 0 must be a USB/PMD-1208FS.
//									Analog signal on an input channel 0.

// ==============================================================================
   

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using MccDaq;

namespace AIn_csNET
{
	public class frmDataDisplay : System.Windows.Forms.Form
	{
		// Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;
		public ToolTip ToolTip1;
		public Button cmdStartConvert;
		public Button cmdStopConvert;
		public Timer tmrConvert;
		public Label lblShowVolts;
		public Label lblVoltsRead;
		public Label lblValueRead;
		public Label lblChanPrompt;
		public Label lblDemoFunction;
		public Label lblShowData;

		//Here's where we declare our variables for the project
		private MccDaq.MccBoard DaqBoard;
		private MccDaq.ErrorInfo ULStat;
		private MccDaq.Range Range;
			 
		public frmDataDisplay()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			//  Initiate error handling
			//   activating error handling will trap errors like
			//   bad channel numbers and non-configured conditions.
			//   Parameters:
			//     MccDaq.ErrorReporting.PrintAll :all warnings and errors encountered will be printed
			//     MccDaq.ErrorHandling.StopAll   :if an error is encountered, the program will stop
			
			ULStat = MccDaq.MccService.ErrHandling(MccDaq.ErrorReporting.PrintAll, MccDaq.ErrorHandling.StopAll);
			//UlStat = integer;
		}

		// Form overrides dispose to clean up the component list.
		protected override void  Dispose(bool Disposing)
		{
			if (Disposing)
			{
					if (components != null)
					{
						components.Dispose();
					}
			}
			base.Dispose(Disposing);
		}

	    
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
	    
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.cmdStartConvert = new System.Windows.Forms.Button();
			this.cmdStopConvert = new System.Windows.Forms.Button();
			this.tmrConvert = new System.Windows.Forms.Timer(this.components);
			this.lblShowVolts = new System.Windows.Forms.Label();
			this.lblVoltsRead = new System.Windows.Forms.Label();
			this.lblValueRead = new System.Windows.Forms.Label();
			this.lblChanPrompt = new System.Windows.Forms.Label();
			this.lblDemoFunction = new System.Windows.Forms.Label();
			this.lblShowData = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// cmdStartConvert
			// 
			this.cmdStartConvert.BackColor = System.Drawing.SystemColors.Control;
			this.cmdStartConvert.Cursor = System.Windows.Forms.Cursors.Default;
			this.cmdStartConvert.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdStartConvert.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdStartConvert.Location = new System.Drawing.Point(232, 176);
			this.cmdStartConvert.Name = "cmdStartConvert";
			this.cmdStartConvert.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.cmdStartConvert.Size = new System.Drawing.Size(52, 26);
			this.cmdStartConvert.TabIndex = 5;
			this.cmdStartConvert.Text = "Start";
			this.cmdStartConvert.Click += new System.EventHandler(this.cmdStartConvert_Click);
			// 
			// cmdStopConvert
			// 
			this.cmdStopConvert.BackColor = System.Drawing.SystemColors.Control;
			this.cmdStopConvert.Cursor = System.Windows.Forms.Cursors.Default;
			this.cmdStopConvert.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdStopConvert.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdStopConvert.Location = new System.Drawing.Point(232, 176);
			this.cmdStopConvert.Name = "cmdStopConvert";
			this.cmdStopConvert.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.cmdStopConvert.Size = new System.Drawing.Size(52, 26);
			this.cmdStopConvert.TabIndex = 6;
			this.cmdStopConvert.Text = "Quit";
			this.cmdStopConvert.Visible = false;
			this.cmdStopConvert.Click += new System.EventHandler(this.cmdStopConvert_Click);
			// 
			// tmrConvert
			// 
			this.tmrConvert.Tick += new System.EventHandler(this.tmrConvert_Tick);
			// 
			// lblShowVolts
			// 
			this.lblShowVolts.BackColor = System.Drawing.SystemColors.Window;
			this.lblShowVolts.Cursor = System.Windows.Forms.Cursors.Default;
			this.lblShowVolts.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblShowVolts.ForeColor = System.Drawing.Color.Blue;
			this.lblShowVolts.Location = new System.Drawing.Point(208, 136);
			this.lblShowVolts.Name = "lblShowVolts";
			this.lblShowVolts.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lblShowVolts.Size = new System.Drawing.Size(80, 16);
			this.lblShowVolts.TabIndex = 8;
			this.lblShowVolts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblVoltsRead
			// 
			this.lblVoltsRead.AutoSize = true;
			this.lblVoltsRead.BackColor = System.Drawing.SystemColors.Window;
			this.lblVoltsRead.Cursor = System.Windows.Forms.Cursors.Default;
			this.lblVoltsRead.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblVoltsRead.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lblVoltsRead.Location = new System.Drawing.Point(48, 136);
			this.lblVoltsRead.Name = "lblVoltsRead";
			this.lblVoltsRead.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lblVoltsRead.Size = new System.Drawing.Size(137, 16);
			this.lblVoltsRead.TabIndex = 7;
			this.lblVoltsRead.Text = "Value converted to voltage:";
			this.lblVoltsRead.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblValueRead
			// 
			this.lblValueRead.AutoSize = true;
			this.lblValueRead.BackColor = System.Drawing.SystemColors.Window;
			this.lblValueRead.Cursor = System.Windows.Forms.Cursors.Default;
			this.lblValueRead.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblValueRead.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lblValueRead.Location = new System.Drawing.Point(16, 104);
			this.lblValueRead.Name = "lblValueRead";
			this.lblValueRead.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lblValueRead.Size = new System.Drawing.Size(171, 16);
			this.lblValueRead.TabIndex = 3;
			this.lblValueRead.Text = "Value read from selected channel:";
			this.lblValueRead.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblChanPrompt
			// 
			this.lblChanPrompt.BackColor = System.Drawing.SystemColors.Window;
			this.lblChanPrompt.Cursor = System.Windows.Forms.Cursors.Default;
			this.lblChanPrompt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblChanPrompt.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblChanPrompt.ForeColor = System.Drawing.Color.Red;
			this.lblChanPrompt.Location = new System.Drawing.Point(16, 40);
			this.lblChanPrompt.Name = "lblChanPrompt";
			this.lblChanPrompt.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lblChanPrompt.Size = new System.Drawing.Size(264, 40);
			this.lblChanPrompt.TabIndex = 1;
			this.lblChanPrompt.Text = "Please connect your signal source to Channel 0 of the USB/PMD-1208FS.  For wiring" +
				" assistance, please see the user\'s guide.";
			this.lblChanPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblDemoFunction
			// 
			this.lblDemoFunction.AutoSize = true;
			this.lblDemoFunction.BackColor = System.Drawing.SystemColors.Window;
			this.lblDemoFunction.Cursor = System.Windows.Forms.Cursors.Default;
			this.lblDemoFunction.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDemoFunction.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lblDemoFunction.Location = new System.Drawing.Point(16, 16);
			this.lblDemoFunction.Name = "lblDemoFunction";
			this.lblDemoFunction.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lblDemoFunction.Size = new System.Drawing.Size(276, 16);
			this.lblDemoFunction.TabIndex = 2;
			this.lblDemoFunction.Text = "Demonstration of MccBoard.AIn and USB/PMD-1208FS";
			this.lblDemoFunction.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lblShowData
			// 
			this.lblShowData.Font = new System.Drawing.Font("Arial", 8F);
			this.lblShowData.ForeColor = System.Drawing.Color.Blue;
			this.lblShowData.Location = new System.Drawing.Point(208, 104);
			this.lblShowData.Name = "lblShowData";
			this.lblShowData.Size = new System.Drawing.Size(80, 16);
			this.lblShowData.TabIndex = 9;
			this.lblShowData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// frmDataDisplay
			// 
			this.AcceptButton = this.cmdStartConvert;
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 13);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(304, 220);
			this.Controls.Add(this.lblShowData);
			this.Controls.Add(this.cmdStartConvert);
			this.Controls.Add(this.cmdStopConvert);
			this.Controls.Add(this.lblShowVolts);
			this.Controls.Add(this.lblVoltsRead);
			this.Controls.Add(this.lblValueRead);
			this.Controls.Add(this.lblChanPrompt);
			this.Controls.Add(this.lblDemoFunction);
			this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ForeColor = System.Drawing.SystemColors.WindowText;
			this.Location = new System.Drawing.Point(182, 100);
			this.Name = "frmDataDisplay";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Universal Library Analog Input";
			this.Load += new System.EventHandler(this.frmDataDisplay_Load);
			this.ResumeLayout(false);

		}

	#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			int BoardNum ;
			int typeVal;
			string myMessage;
	
			MccDaq.ErrorInfo ULStat;
			MccDaq.MccBoard DaqBoard;
			
			//  Create a new MccBoard object for Board 1
			BoardNum = 0;
			DaqBoard = new MccDaq.MccBoard(BoardNum);	//<======this is the default board number
			//change it to what InstaCal has 
			//assigned for your USB/PMD-1208FS
			ULStat = DaqBoard.BoardConfig.GetBoardType(out typeVal);  // Get the typeVal property from the MccBoard object
			if (typeVal == 130)  //Code for USB/PMD-1208FS is 130
			{	
				Application.Run(new frmDataDisplay());
			}
			else
			{
				myMessage = "A USB/PMD-1208FS was not assigned to Board " + BoardNum + " in InstaCal.\n"//+ 
					+ "Please run InstaCal to verify the board number\n" 
					+ "and/or change BoardNum = " + BoardNum + " in the Form_Load event\n" 
					+ " to the correct board number.  Then re-run this program.";
				MessageBox.Show(myMessage,  "USB/PMD-1208FS not detected.", MessageBoxButtons.OK);
			}
		}
	 
		private void cmdStartConvert_Click(object eventSender, System.EventArgs eventArgs) /* Handles cmdStartConvert.Click */
		{
			cmdStartConvert.Visible = false;
			cmdStopConvert.Visible = true;
			tmrConvert.Enabled = true;
		}

		private void cmdStopConvert_Click(object eventSender, System.EventArgs eventArgs) /* Handles cmdStopConvert.Click */
		{
			tmrConvert.Enabled = false;
			Application.ExitThread();
		}

		private void frmDataDisplay_Load(object eventSender, System.EventArgs eventArgs) /* Handles base.Load */
		{
			int BoardNum;

			BoardNum = 0;
			DaqBoard = new MccDaq.MccBoard(BoardNum);
		}

		private void tmrConvert_Tick(object eventSender, System.EventArgs eventArgs) /* Handles tmrConvert.Tick */
		{
			float EngUnits;
			System.UInt16 DataValue;
			int Chan;

			//  Collect the data by calling AIn memeber function of MccBoard object
			//   Parameters:
			//     Chan       :the input channel number
			//     Range      :the Range for the board.
			//     DataValue  :the name for the value collected
			Range = Range.Bip10Volts;		//  select Bip10Volts (member of Range enumeration)
			Chan = 0;						//  set input channel

			ULStat = DaqBoard.AIn( Chan, Range, out DataValue);
			if (ULStat.Value == MccDaq.ErrorInfo.ErrorCode.BadRange)
			{
				MessageBox.Show( "Change the Range argument to one supported by this board.", "Unsupported Range", MessageBoxButtons.OK);
				Application.Exit();
			}
			
			//  Convert raw data to Volts by calling ToEngUnits (member function of MccBoard class)
			ULStat = DaqBoard.ToEngUnits( Range, DataValue, out EngUnits);

			lblShowData.Text = DataValue.ToString();                //  print the counts
			lblShowVolts.Text = EngUnits.ToString("F4") + " Volts"; //  print the voltage
		}
	}
}