﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;


namespace CDIO_Demo
{
    class RunMe
    {
        [STAThread]
        public static int Main(String[] args)
        {
            Controller controller = new Controller();
            //StartListening();
            return 0;
        }
    }
    
    public class Controller
    {
        private ManualResetEvent allDone = new ManualResetEvent(false);
        private SocketAsync socketAsync;
        private UsbConnection usbCon;

        public Controller()
        {
            this.usbCon = new UsbConnection(0);
            this.socketAsync = new SocketAsync(this.allDone, this.usbCon);
            this.socketAsync.StartListening();
        }
     
    }
}
