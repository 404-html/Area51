﻿using System;
using System.Collections.Generic;
using System.Text;

using System.ComponentModel;

using System.Data;
using System.Diagnostics;

//using MccDaq;

using System.Management; 

namespace CDIO_Demo
{
    public class UsbConnection
    {

        //private MccDaq.MccBoard DaqBoard;
        //private MccDaq.ErrorInfo ULStat;
        //private MccDaq.Range Range;
        private int boardNum;


        public UsbConnection(int boardNum)
        {
            //  Initiate error handling
            //   activating error handling will trap errors like
            //   bad channel numbers and non-configured conditions.
            //   Parameters:
            //     MccDaq.ErrorReporting.PrintAll :all warnings and errors encountered will be printed
            //     MccDaq.ErrorHandling.StopAll   :if an error is encountered, the program will stop

            
            
            //UlStat = integer;

            this.boardNum = boardNum;

            //this.DaqBoard = new MccDaq.MccBoard(this.boardNum);

            int typeVal;
            string myMessage;
            
        }

        public Boolean connect()
        {
            int CurIndex;
            int CurCount;
            short Status;
            int typeVal;
            String err = String.Empty;

            
            //ULStat = DaqBoard.GetStatus(out Status, out CurCount, out CurIndex, MccDaq.FunctionType.AiFunction);
            
            //Console.WriteLine("board:" + this.DaqBoard.BoardName + "|" + checkUSBdeviceConnection());
            if (checkUSBdeviceConnection())
            {
                //if (this.DaqBoard == null) //connection not established yet
                //{
                //    this.DaqBoard = new MccDaq.MccBoard(this.boardNum);
                //    ULStat = MccDaq.MccService.ErrHandling(MccDaq.ErrorReporting.PrintAll, MccDaq.ErrorHandling.DontStop);
                //}
                return true;
            }
            else
            {
                return false;
            }
        }

        public String doMeasure()
        {
            float EngUnits=0;
            System.UInt16 DataValue;
            int Chan;

            //  Collect the data by calling AIn memeber function of MccBoard object
            //   Parameters:
            //     Chan       :the input channel number
            //     Range      :the Range for the board.
            //     DataValue  :the name for the value collected

            ////FS-1208 understøtter kun +-10 v input range
            //Range = Range.Bip10Volts;		//  select Bip10Volts (member of Range enumeration)
            //Chan = 0;						//  set input channel

            //ULStat = DaqBoard.AIn(Chan, Range, out DataValue); //aflæs værdien på den valgte kanal
            //if (ULStat.Value == MccDaq.ErrorInfo.ErrorCode.BadRange)
            //{
            //    Console.WriteLine("Change the Range argument to one supported by this board.");
            //    //MessageBox.Show("Change the Range argument to one supported by this board.", "Unsupported Range", MessageBoxButtons.OK);
            //    //Application.Exit();
            //}

            ////  Convert raw data to Volts by calling ToEngUnits (member function of MccBoard class)
            //ULStat = DaqBoard.ToEngUnits(Range, DataValue, out EngUnits);

            //lblShowData.Text = DataValue.ToString();                //  print the counts
            return EngUnits.ToString("F4", System.Globalization.CultureInfo.InvariantCulture); //  print the voltage
        }

        //-----------------

        List<USBDeviceInfo> GetUSBDevices() //not used. For testing.
        {
            List<USBDeviceInfo> devices = new List<USBDeviceInfo>();

            ManagementObjectCollection collection;
            using (var searcher = new ManagementObjectSearcher(@"Select * From Win32_USBHub"))
                collection = searcher.Get();

            foreach (var device in collection)
            {
                devices.Add(new USBDeviceInfo(
                (string)device.GetPropertyValue("DeviceID"),
                (string)device.GetPropertyValue("PNPDeviceID"),
                (string)device.GetPropertyValue("Description")
                ));
            }

            collection.Dispose();
            return devices;
        }

        //checks system if usb device is connected
        Boolean checkUSBdeviceConnection()
        {
            Boolean returnVal = false;
            
            ManagementObjectCollection collection;
            using (var searcher = new ManagementObjectSearcher(@"Select * From Win32_USBHub"))
                collection = searcher.Get();

            foreach (var device in collection)
            {
                if (((string)device.GetPropertyValue("DeviceID")).Contains("VID_09DB&PID_0082"))
                {
                    returnVal = true;
                    break;
                }

           }

            collection.Dispose();
            return returnVal;
        }

        //class Program
        //{
        //    static void Main(string[] args)
        //    {
        //        var usbDevices = GetUSBDevices();

        //        foreach (var usbDevice in usbDevices)
        //        {
        //            Console.WriteLine("Device ID: {0}, PNP Device ID: {1}, Description: {2}",
        //                usbDevice.DeviceID, usbDevice.PnpDeviceID, usbDevice.Description);
        //        }

        //        Console.Read();
        //    }


        //}

    }

    class USBDeviceInfo
    {
        public USBDeviceInfo(string deviceID, string pnpDeviceID, string description)
        {
            this.DeviceID = deviceID;
            this.PnpDeviceID = pnpDeviceID;
            this.Description = description;
        }
        public string DeviceID { get; private set; }
        public string PnpDeviceID { get; private set; }
        public string Description { get; private set; }
    }

}
