﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;

//using MccDaq;
using System.Management; 

namespace USBConnector
{
    public class UsbConnection
    {

        //private MccDaq.MccBoard DaqBoard; //det fysiske DAQ device
        //private MccDaq.ErrorInfo ULStat; //returværdien fra DAQ device
        //private MccDaq.Range Range; //det spændingsområde der måles i
        private int boardNum; //det device nummer, som DAQen er konfigureret med (der kan være flere)

        public UsbConnection(int boardNum)
        {
            //  Initiate error handling
            //   activating error handling will trap errors like
            //   bad channel numbers and non-configured conditions.
            //   Parameters:
            //     MccDaq.ErrorReporting.PrintAll :all warnings and errors encountered will be printed
            //     MccDaq.ErrorHandling.StopAll   :if an error is encountered, the program will stop

            this.boardNum = boardNum;

            int typeVal;
            string myMessage;

        }

        //opretter instans af DAQ, hvis ikke den eksisterer i forvejen
        public Boolean connect()
        {
            //int CurIndex;
            //int CurCount;
            //short Status;
            //int typeVal;
            //String err = String.Empty;
         
            //if (checkUSBdeviceConnection())
            //{
            //    if (this.DaqBoard == null) //connection not established yet
            //    {
            //        this.DaqBoard = new MccDaq.MccBoard(this.boardNum);
            //        ULStat = MccDaq.MccService.ErrHandling(MccDaq.ErrorReporting.PrintAll, MccDaq.ErrorHandling.DontStop);
            //    }
            //    return true;
            //}
            //else
            //{
                return false;
            //}
        }

        public String doMeasure()
        {
            //float EngUnits;
            //System.UInt16 DataValue;
            //int Chan;

            ////  Collect the data by calling AIn memeber function of MccBoard object
            ////   Parameters:
            ////     Chan       :the input channel number
            ////     Range      :the Range for the board.
            ////     DataValue  :the name for the value collected

            ////FS-1208 understøtter kun +-10 v input range .Bip10Volts
            //Range = Range.Bip10Volts;		//  select Bip10Volts (member of Range enumeration)
            //Chan = 0;						//  set input channel

            //ULStat = DaqBoard.AIn(Chan, Range, out DataValue); //aflæs værdien på den valgte kanal
            //if (ULStat.Value == MccDaq.ErrorInfo.ErrorCode.BadRange)
            //{
            //    Console.WriteLine("Change the Range argument to one supported by this board.");
            //}

            ////  Convert raw data to Volts by calling ToEngUnits (member function of MccBoard class)
            //ULStat = DaqBoard.ToEngUnits(Range, DataValue, out EngUnits);
            //Console.WriteLine("Måling:" + ULStat);
            ////konverterer til 10 decimaler
            //return EngUnits.ToString("F10", System.Globalization.CultureInfo.InvariantCulture); //  print the voltage
            return null;
        }

        //checks system if usb device is connected
        Boolean checkUSBdeviceConnection()
        {
            Boolean returnVal = false;
            
            ManagementObjectCollection collection;
            //udvælger alle devices der er forbundet via USB og tilføjer til collection
            using (var searcher = new ManagementObjectSearcher(@"Select * From Win32_USBHub"))
                collection = searcher.Get();

            foreach (var device in collection)
            {   //checker om FS1208 er forbundet via den specifikke streng
                if (((string)device.GetPropertyValue("DeviceID")).Contains("VID_09DB&PID_0082")) 
                {
                    returnVal = true;
                    break;
                }

           }

            collection.Dispose();
            return returnVal;
        }

        List<USBDeviceInfo> GetUSBDevices() //bruges ikke, kun til test
        {
            List<USBDeviceInfo> devices = new List<USBDeviceInfo>();

            ManagementObjectCollection collection;
            using (var searcher = new ManagementObjectSearcher(@"Select * From Win32_USBHub"))
                collection = searcher.Get();

            foreach (var device in collection)
            {
                devices.Add(new USBDeviceInfo(
                (string)device.GetPropertyValue("DeviceID"),
                (string)device.GetPropertyValue("PNPDeviceID"),
                (string)device.GetPropertyValue("Description")
                ));
            }

            collection.Dispose();
            return devices;
        }

        //kun til test, hvis nyt device ID skal findes 
        //class Program
        //{
        //    static void Main(string[] args)
        //    {
        //        var usbDevices = GetUSBDevices();

        //        foreach (var usbDevice in usbDevices)
        //        {
        //            Console.WriteLine("Device ID: {0}, PNP Device ID: {1}, Description: {2}",
        //                usbDevice.DeviceID, usbDevice.PnpDeviceID, usbDevice.Description);
        //        }

        //        Console.Read();
        //    }


        //}

    }

    class USBDeviceInfo
    {
        public USBDeviceInfo(string deviceID, string pnpDeviceID, string description)
        {
            this.DeviceID = deviceID;
            this.PnpDeviceID = pnpDeviceID;
            this.Description = description;
        }
        public string DeviceID { get; private set; }
        public string PnpDeviceID { get; private set; }
        public string Description { get; private set; }
    }

}
