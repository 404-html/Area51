﻿using System;
using System.Collections.Generic;
using System.Text;

namespace USBConnector
{
    using System;
    using System.Net;
    using System.Net.Sockets;
    using System.Text;
    using System.Threading;

    // State object for reading client data asynchronously
    public class StateObject
    {
        // Client  socket.
        public Socket workSocket = null;
        // Size of receive buffer.
        public const int BufferSize = 1024;
        // Receive buffer.
        public byte[] buffer = new byte[BufferSize];
        // Received data string.
        public StringBuilder sb = new StringBuilder();
    }

    public class SocketAsync
    {
        // Thread signal.
        private ManualResetEvent allDone;
        private UsbConnection usbCon;
        private int counter = 0;

        public SocketAsync(ManualResetEvent allDone, UsbConnection usbCon)
        {
            this.allDone = allDone;
            this.usbCon = usbCon;
            //StartListening();
        }

        public StateObject StateObject
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public void StartListening()
        {
            // Data buffer for incoming data.
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.
            // The DNS name of the computer
            // running the listener is "host.contoso.com".
            IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            //IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 4567);
            IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Any, 4567);

            // Create a TCP/IP socket.
            Socket listener = new Socket(AddressFamily.InterNetwork,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and listen for incoming connections.
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(100);

                while (true)
                {
                    // Set the event to nonsignaled state.
                    allDone.Reset();

                    // Start an asynchronous socket to listen for connections.
                    Console.WriteLine("-----------------------BEGIN" + ++counter + "-------------------------------");
                    Console.WriteLine("Waiting for a connection on IP address: " + ipAddress);
                    Console.WriteLine("connected to USB: " + usbCon.connect());
                    //System.Threading.Thread.Sleep(1000);
                    listener.BeginAccept(
                        new AsyncCallback(AcceptCallback),
                        listener);

                    // Wait until a connection is made before continuing.

                    allDone.WaitOne();

                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }

        public void AcceptCallback(IAsyncResult ar)
        {


            // Get the socket that handles the client request.
            Socket listener = (Socket)ar.AsyncState;
            Socket handler = listener.EndAccept(ar);

            // Create the state object.
            StateObject state = new StateObject();
            state.workSocket = handler;

            IPEndPoint remoteIpEndPoint = handler.RemoteEndPoint as IPEndPoint;

            Console.WriteLine("Connection from:" + remoteIpEndPoint.Address);

            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                new AsyncCallback(ReadCallback), state);


        }

        public void ReadCallback(IAsyncResult ar)
        {
            String content = String.Empty;


            // Retrieve the state object and the handler socket
            // from the asynchronous state object.
            StateObject state = (StateObject)ar.AsyncState;
            Socket handler = state.workSocket;

            // Read data from the client socket. 
            //der skal være try catch her
            int bytesRead = 0;

            try
            {
                bytesRead = handler.EndReceive(ar);
            }
            catch (Exception e)
            {
                handler.Shutdown(SocketShutdown.Both);
                handler.Close();
            }

            if (bytesRead > 0)
            {
                // There  might be more data, so store the data received so far.
                state.sb.Append(Encoding.ASCII.GetString(
                    state.buffer, 0, bytesRead));

                // Check for end-of-file tag. If it is not there, read 
                // more data.
                content = state.sb.ToString();
                if (content.IndexOf("<EOF>") > -1)
                {
                    // All the data has been read from the 
                    // client. Display it on the console.
                    Console.WriteLine("Read {0} bytes from socket. \n Data : {1} |timestamp:" + DateTime.Now, content.Length, content);

                    // Echo the data back to the client.
                    //Send(handler, content);
                    //Send(handler, "ERROR;03");
                    //UsbConnection usbCon = new UsbConnection(0);
                    //String returnString = usbCon.doMeasure() + ";555";
                    String returnString = doMeasurement(content);
                    //System.Threading.Thread.Sleep(1000);

                    Send(handler, returnString + "\n");
                    Console.WriteLine("Sent: " + returnString);

                    Array.Clear(state.buffer, 0, state.buffer.Length);
                    state.sb.Remove(0, state.sb.Length);

                    handler.ReceiveTimeout = 1000;

                    handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                        new AsyncCallback(ReadCallback), state);

                }
                else
                {
                    // Not all data received. Get more.
                    if (handler.Connected)
                    {
                        handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                        new AsyncCallback(ReadCallback), state);
                    }
                }
            }
        }

        private void Send(Socket handler, String data)
        {
            // Convert the string data to byte data using ASCII encoding.
            byte[] byteData = Encoding.ASCII.GetBytes(data);

            // Begin sending the data to the remote device.
            handler.BeginSend(byteData, 0, byteData.Length, 0,
                new AsyncCallback(SendCallback), handler);
            Console.WriteLine("sent data");
        }

        private void SendCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.
                Socket handler = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.
                int bytesSent = handler.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to client.", bytesSent);
                Console.WriteLine("------------------------END" + counter + "--------------------------------");
                //handler.Shutdown(SocketShutdown.Both);
                //handler.Close();

                // Signal the main thread to continue.
                allDone.Set();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private String doMeasurement(String javaString)
        {
            char[] delimiterChars = { ';' };
            String[] javaRecieveString = javaString.Split(delimiterChars);

            int portNumber;
            int numberMeasurements;
            int period;

            try
            {
                portNumber = Convert.ToInt32(javaRecieveString[0]);
                numberMeasurements = Convert.ToInt32(javaRecieveString[1]);
                period = Convert.ToInt32(javaRecieveString[2]);
            }
            catch (Exception e)
            {
                //if error return error code 05 (05: Message does not conform to protocol)
                return "ERROR;05";
            }

            switch (portNumber)
            {
                case 0:
                    if (usbCon.connect())
                    {
                        Console.WriteLine("forsøger måling");
                        return usbCon.doMeasure() + ";1";
                    }
                    else
                    {
                        //USB device not connected
                        return "ERROR;01";
                    }
                    break;
                case 98:
                    Console.WriteLine("test 98 måling");
                    return "1;1";
                    //test port, always returns value 1
                    break;
                case 99:
                    //test port, returns random value between 0 and 2
                    Console.WriteLine("test 99 måling");
                    Random r = new Random();
                    float rNum = ((float)r.NextDouble()) * 2;
                    String rString = rNum.ToString("F4", System.Globalization.CultureInfo.InvariantCulture);
                    return rString + ";1";

                    break;
                default:
                    //return illegal port number
                    return "ERROR;02";
                    break;

            }

            //return unknown error
            return "ERROR;05";
        }



        //public static int Main(String[] args)
        //{
        //    StartListening();
        //    return 0;
        //}
    }
}
